def count_pixels(image, target_color):
    count = 0
    for row in image:
        count += row.count(target_color)
    return count


def flood_fill_even(image, x, y, replacement_color):
    target_color = image[x][y]
    if target_color == replacement_color:
        return image

    stack = [(x, y)]

    while stack:
        current_x, current_y = stack.pop()
        image[current_x][current_y] = replacement_color

        for dx, dy in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
            new_x, new_y = current_x + dx, current_y + dy
            if 0 <= new_x < len(image) and 0 <= new_y < len(image[0]):
                if image[new_x][new_y] == target_color:
                    stack.append((new_x, new_y))

    return image


def flood_fill_even_criteria(image, x, y, replacement_color):
    target_color = image[x][y]
    if target_color == replacement_color:
        return image
    pixel_count = count_pixels(image, target_color)
    if pixel_count % 2 == 0:
        return flood_fill_even(image, x, y, replacement_color)
    else:
        return image
