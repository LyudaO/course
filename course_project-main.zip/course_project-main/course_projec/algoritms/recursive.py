def fill_recursive(image, x, y, target_color, replacement_color):
    if x < 0 or x >= len(image) or y < 0 or y >= len(image[0]) or image[x][y] != target_color:
        return image

    image[x][y] = replacement_color

    fill_recursive(image, x + 1, y, target_color, replacement_color)
    fill_recursive(image, x - 1, y, target_color, replacement_color)
    fill_recursive(image, x, y + 1, target_color, replacement_color)
    fill_recursive(image, x, y - 1, target_color, replacement_color)

    return image


def flood_fill(image, x, y, replacement_color):
    target_color = image[x][y]
    if target_color == replacement_color:
        return image
    fill_recursive(image, x, y, target_color, replacement_color)
    return image


