import numpy as np
from PIL import Image


def fill_polygon_with_texture_matrix(image_matrix, polygon_points, texture_matrix):
    for y in range(image_matrix.shape[0]):
        for x in range(image_matrix.shape[1]):
            if point_inside_polygon(x, y, polygon_points):
                image_matrix[y][x] = texture_matrix[y % texture_matrix.shape[0]][x % texture_matrix.shape[1]]


def point_inside_polygon(x, y, polygon_points):
    odd_nodes = False
    j = len(polygon_points) - 1
    for i in range(len(polygon_points)):
        if (polygon_points[i][1] < y and polygon_points[j][1] >= y) or (polygon_points[j][1] < y and polygon_points[i][1] >= y):
            if polygon_points[i][0] + (y - polygon_points[i][1]) / (polygon_points[j][1] - polygon_points[i][1]) * (polygon_points[j][0] - polygon_points[i][0]) < x:
                odd_nodes = not odd_nodes
        j = i
    return odd_nodes
