def edge_table(polygon):
    edges = []
    for i in range(len(polygon)):
        p1 = polygon[i]
        p2 = polygon[(i + 1) % len(polygon)]
        if p1[1] < p2[1]:
            edges.append((p1, p2))
        else:
            edges.append((p2, p1))
    return sorted(edges, key=lambda x: x[0][1])


def yx_algorithm(image, polygon, color):
    edges = edge_table(polygon)

    min_y = edges[0][0][1]
    max_y = edges[-1][1][1]

    active_edges = []
    x_intersections = []

    for y in range(min_y, max_y + 1):
        while edges and edges[0][0][1] == y:
            active_edges.append(edges.pop(0))

        active_edges = [edge for edge in active_edges if edge[1][1] != y]

        for edge in active_edges:
            x_intersections.append(edge[0][0] + (edge[1][0] - edge[0][0]) * (y - edge[0][1]) / (edge[1][1] - edge[0][1]))

        x_intersections.sort()

        for i in range(0, len(x_intersections), 2):
            x_start = max(0, int(x_intersections[i]))
            x_end = min(len(image[0]) - 1, int(x_intersections[i + 1]))
            for x in range(x_start, x_end + 1):
                image[y][x] = color

        x_intersections.clear()

    return image
