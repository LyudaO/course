from GUI import GUI

if __name__ == "__main__":
    try:
        app = GUI()
        app.mainloop()
    except:
        print("Виникла помилка, будь ласка, перевірте коректність роботи програми")