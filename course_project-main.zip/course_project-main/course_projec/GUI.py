import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import numpy as np


from algoritms import even_algo, flood, rastr_algo, recursive, texture_algo, yx_algo


class GUI(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("Алгоритми Зафарбовування Фігур")
        self.geometry("600x400")

        self.tab_control = ttk.Notebook(self)

        self.tab_recursive = ttk.Frame(self.tab_control)
        self.tab_control.add(self.tab_recursive, text='Рекурсивний')
        self.recursive_canvas = tk.Canvas(self.tab_recursive, width=300, height=300)
        self.recursive_canvas.pack(side=tk.LEFT, padx=10, pady=10)
        self.recursive_canvas.bind("<Button-1>", self.add_point_recursive)
        self.recursive_button = tk.Button(self.tab_recursive, text="Застосувати", command=self.apply_recursive)
        self.recursive_button.pack(pady=10)
        self.points_recursive = []

        self.tab_scanline = ttk.Frame(self.tab_control)
        self.tab_control.add(self.tab_scanline, text='Пострічковий')
        self.scanline_canvas = tk.Canvas(self.tab_scanline, width=300, height=300)
        self.scanline_canvas.pack(side=tk.LEFT, padx=10, pady=10)
        self.scanline_canvas.bind("<Button-1>", self.add_point_scanline)
        self.scanline_button = tk.Button(self.tab_scanline, text="Застосувати", command=self.apply_scanline)
        self.scanline_button.pack(pady=10)
        self.points_scanline = []

        self.tab_even = ttk.Frame(self.tab_control)
        self.tab_control.add(self.tab_even, text='Парність')
        self.even_canvas = tk.Canvas(self.tab_even, width=300, height=300)
        self.even_canvas.pack(side=tk.LEFT, padx=10, pady=10)
        self.even_canvas.bind("<Button-1>", self.add_point_even)
        self.even_button = tk.Button(self.tab_even, text="Застосувати", command=self.apply_even)
        self.even_button.pack(pady=10)
        self.points_even = []


        self.tab_yx = ttk.Frame(self.tab_control)
        self.tab_control.add(self.tab_yx, text='Зафарбування YX')
        self.yx_canvas = tk.Canvas(self.tab_yx, width=300, height=300)
        self.yx_canvas.pack(side=tk.LEFT, padx=10, pady=10)
        self.yx_canvas.bind("<Button-1>", self.add_point_yx)
        self.yx_button = tk.Button(self.tab_yx, text="Застосувати", command=self.apply_yx)
        self.yx_button.pack(pady=10)
        self.points_yx = []

        self.tab_control.pack(expand=1, fill="both")

        self.result_canvas = tk.Canvas(self, width=300, height=300)
        self.result_canvas.pack(pady=10)

    def add_point_recursive(self, event):
        self.points_recursive.append((event.x, event.y))
        self.recursive_canvas.create_oval(event.x - 3, event.y - 3, event.x + 3, event.y + 3, fill='black')

    def apply_recursive(self):
        if self.points_recursive:
            image = np.zeros((300, 300), dtype=int)
            for point in self.points_recursive:
                image[point[1]][point[0]] = 1

            result_image = flood.flood_fill_seed(image, self.points_recursive[0][0], self.points_recursive[0][1], 2)
            self.display_image(result_image)

    def add_point_scanline(self, event):
        self.points_scanline.append((event.x, event.y))
        self.scanline_canvas.create_oval(event.x - 3, event.y - 3, event.x + 3, event.y + 3, fill='black')

    def apply_scanline(self):
        if self.points_scanline:
            image = np.zeros((300, 300), dtype=int)
            for point in self.points_scanline:
                image[point[1]][point[0]] = 1

            result_image = yx_algo.yx_algorithm(image, self.points_scanline, 1)
            self.display_image(result_image)

    def add_point_even(self, event):
        self.points_even.append((event.x, event.y))
        self.even_canvas.create_oval(event.x - 3, event.y - 3, event.x + 3, event.y + 3, fill='black')

    def apply_even(self):
        if self.points_even:
            image = np.zeros((300, 300), dtype=int)
            for point in self.points_even:
                image[point[1]][point[0]] = 1

            result_image = even_algo.flood_fill_even_criteria(image, self.points_even, self.points_recursive[0][0], self.points_recursive[0][1])
            self.display_image(result_image)

    def add_point_yx(self, event):
        self.points_yx.append((event.x, event.y))
        self.yx_canvas.create_oval(event.x - 3, event.y - 3, event.x + 3, event.y + 3, fill='black')

    def apply_yx(self):
        if self.points_yx:
            image = np.zeros((300, 300), dtype=int)
            for point in self.points_yx:
                image[point[1]][point[0]] = 1

            result_image = texture_algo.fill_polygon_with_texture_matrix(image, self.points_yx, self.points_yx)
            self.display_image(result_image)

    def display_image(self, image):
        img = Image.fromarray(np.uint8(image) * 255)
        img = img.resize((300, 300), Image.DEFAULT_STRATEGY)
        img_tk = ImageTk.PhotoImage(image=img)
        self.result_canvas.image = img_tk
        self.result_canvas.create_image(0, 0, anchor='nw', image=img_tk)
